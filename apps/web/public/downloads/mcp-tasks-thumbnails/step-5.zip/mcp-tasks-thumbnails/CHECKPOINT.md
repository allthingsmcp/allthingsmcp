# step-5

This project contains the code at the end of step 5.
Run pnpm install --frozen-lockfile, then pnpm run fixtures.
Continue at step 6 of the ATM Guide.
Generated images and task records are not included.

# starter

This is the starter project for step 2.
Run pnpm install --frozen-lockfile, then pnpm run fixtures.
Use this starter in step 2 of the ATM Guide.
Generated images and task records are not included.

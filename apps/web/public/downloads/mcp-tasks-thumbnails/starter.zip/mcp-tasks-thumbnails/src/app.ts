import { createMcpHandler, McpServer } from '@modelcontextprotocol/server';
import type { BatchOptions } from './thumbnails.ts';
import type { TaskWorker } from './task-worker.ts';
export function createApp(_options: BatchOptions, _worker?: TaskWorker) {
  return createMcpHandler(() => new McpServer({ name: 'thumbnail-server', version: '1.0.0' }), { legacy: 'reject' });
}

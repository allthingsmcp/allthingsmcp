import type { CallToolResultV2 } from '@modelcontextprotocol/ext-tasks/core/v2';
import type { Connection } from './connection.ts';
export async function watchTask(_connection: Connection, _taskId: string, _log = console.log): Promise<CallToolResultV2 | undefined> {
  throw new Error('TODO: implement task polling in step 4.');
}

import type { McpServer } from '@modelcontextprotocol/server';
import type { TaskWorker } from './task-worker.ts';
// TODO: register the Tasks handlers in step 3.
export function registerTaskHandlers(_server: McpServer, _worker: TaskWorker) {}

# completed

This project contains the code at the end of step 6.
Run pnpm install --frozen-lockfile, then pnpm run fixtures.
You have the completed project for all six Guide steps.
Generated images and task records are not included.

# step-4

This project contains the code at the end of step 4.
Run pnpm install --frozen-lockfile, then pnpm run fixtures.
Continue at step 5 of the ATM Guide.
Generated images and task records are not included.

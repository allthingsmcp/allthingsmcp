# step-2

This project contains the code at the end of step 2.
Run pnpm install --frozen-lockfile, then pnpm run fixtures.
Continue at step 3 of the ATM Guide.
Generated images and task records are not included.

# step-3

This project contains the code at the end of step 3.
Run pnpm install --frozen-lockfile, then pnpm run fixtures.
Continue at step 4 of the ATM Guide.
Generated images and task records are not included.
